license-key (license key from your Dashboard on Nextpost.tech (https://nextpost.tech))
username (your Instagram username)
password
proxy (3 to skip)
speed_value (value from 10000 to 500000, or just simple type 0 for maximum speed, but remember that maximum speed might be risky and you can get exception "Throttled by Instagram because of too many API requests" block for half a day, if this account actively used by user in Instagram app in the same time)
target_1, target_2, target_3, ... ,target_n (targets names without "@" symbol)
1